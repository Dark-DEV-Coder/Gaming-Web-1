-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 11, 2022 at 04:55 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laptop`
--

-- --------------------------------------------------------

--
-- Table structure for table `chitiethoadon`
--

CREATE TABLE `chitiethoadon` (
  `MaHD` varchar(8) NOT NULL,
  `MaNhomSP` varchar(8) NOT NULL,
  `DonGia` int(10) UNSIGNED NOT NULL,
  `SoLuong` tinyint(3) UNSIGNED NOT NULL,
  `TienKM` int(10) UNSIGNED NOT NULL,
  `ThanhTien` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chitiethoadon`
--

INSERT INTO `chitiethoadon` (`MaHD`, `MaNhomSP`, `DonGia`, `SoLuong`, `TienKM`, `ThanhTien`) VALUES
('HD1', 'N10', 27500000, 2, 0, 55000000),
('HD2', 'N13', 45100000, 2, 0, 90200000),
('HD7', 'N10', 27500000, 1, 0, 27500000);

-- --------------------------------------------------------

--
-- Table structure for table `chitietkhuyenmai`
--

CREATE TABLE `chitietkhuyenmai` (
  `MaKM` varchar(8) NOT NULL,
  `MaNhomSP` varchar(8) NOT NULL,
  `PhanTramKM` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chitietkhuyenmai`
--

INSERT INTO `chitietkhuyenmai` (`MaKM`, `MaNhomSP`, `PhanTramKM`) VALUES
('KM2', 'N4', 6),
('KM2', 'N8', 4),
('KM3', 'N11', 5),
('KM3', 'N20', 5),
('KM2', 'N20', 3);

-- --------------------------------------------------------

--
-- Table structure for table `chitietphieunhaphang`
--

CREATE TABLE `chitietphieunhaphang` (
  `MaPN` varchar(8) NOT NULL,
  `MaNhomSP` varchar(8) NOT NULL,
  `DonGia` int(10) UNSIGNED NOT NULL,
  `SoLuong` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chitietphieunhaphang`
--

INSERT INTO `chitietphieunhaphang` (`MaPN`, `MaNhomSP`, `DonGia`, `SoLuong`) VALUES
('PN02', 'N1', 23000000, 5),
('PN02', 'N10', 24000000, 5),
('PN03', 'N10', 25000000, 10),
('PN04', 'N20', 26000000, 10),
('PN05', 'N13', 41000000, 7),
('PN03', 'N1', 26000000, 10);

-- --------------------------------------------------------

--
-- Table structure for table `chitietquyen`
--

CREATE TABLE `chitietquyen` (
  `MaQuyen` varchar(8) NOT NULL,
  `MaChucNang` varchar(8) NOT NULL,
  `stt` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chitietquyen`
--

INSERT INTO `chitietquyen` (`MaQuyen`, `MaChucNang`, `stt`) VALUES
('QUANLY', 'HD', 1),
('QUANLY', 'KH', 2),
('QUANLY', 'KM', 3),
('QUANLY', 'NV', 4),
('QUANLY', 'PBH', 5),
('QUANLY', 'PNH', 6),
('QUANLY', 'SP', 7),
('QUANLY', 'TK', 8),
('NHANVIEN', 'HD', 1),
('NHANVIEN', 'KH', 2),
('NHANVIEN', 'PBH', 3),
('NHANVIEN', 'PNH', 4),
('NHANVIEN', 'SP', 5),
('ADMIN', 'TK', 1),
('abc', 'HD', 1),
('abc', 'PBH', 2),
('abc', 'SP', 3);

-- --------------------------------------------------------

--
-- Table structure for table `chitietsanpham`
--

CREATE TABLE `chitietsanpham` (
  `MaSanPham` varchar(8) NOT NULL,
  `MaNhomSP` varchar(8) NOT NULL,
  `TinhTrang` tinyint(1) UNSIGNED NOT NULL,
  `stt` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chitietsanpham`
--

INSERT INTO `chitietsanpham` (`MaSanPham`, `MaNhomSP`, `TinhTrang`, `stt`) VALUES
('N10SP1', 'N10', 2, 1),
('N10SP10', 'N10', 0, 10),
('N10SP2', 'N10', 2, 2),
('N10SP3', 'N10', 0, 3),
('N10SP4', 'N10', 0, 4),
('N10SP5', 'N10', 0, 5),
('N10SP6', 'N10', 0, 6),
('N10SP7', 'N10', 0, 7),
('N10SP8', 'N10', 0, 8),
('N10SP9', 'N10', 0, 9),
('N13SP1', 'N13', 0, 1),
('N13SP2', 'N13', 0, 2),
('N13SP3', 'N13', 0, 3),
('N13SP4', 'N13', 0, 4),
('N13SP5', 'N13', 0, 5),
('N13SP6', 'N13', 0, 6),
('N13SP7', 'N13', 0, 7),
('N1SP1', 'N1', 0, 1),
('N1SP10', 'N1', 0, 10),
('N1SP2', 'N1', 0, 2),
('N1SP3', 'N1', 0, 3),
('N1SP4', 'N1', 0, 4),
('N1SP5', 'N1', 0, 5),
('N1SP6', 'N1', 0, 6),
('N1SP7', 'N1', 0, 7),
('N1SP8', 'N1', 0, 8),
('N1SP9', 'N1', 0, 9),
('N20SP1', 'N20', 0, 1),
('N20SP10', 'N20', 0, 10),
('N20SP2', 'N20', 0, 2),
('N20SP3', 'N20', 0, 3),
('N20SP4', 'N20', 0, 4),
('N20SP5', 'N20', 0, 5),
('N20SP6', 'N20', 0, 6),
('N20SP7', 'N20', 0, 7),
('N20SP8', 'N20', 0, 8),
('N20SP9', 'N20', 0, 9);

-- --------------------------------------------------------

--
-- Table structure for table `chitietsanphamhoadon`
--

CREATE TABLE `chitietsanphamhoadon` (
  `MaHD` varchar(8) NOT NULL,
  `MaSanPham` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chitietsanphamhoadon`
--

INSERT INTO `chitietsanphamhoadon` (`MaHD`, `MaSanPham`) VALUES
('HD2', 'N13SP1'),
('HD2', 'N13SP2'),
('HD2', 'N13SP3'),
('HD7', 'N10SP1'),
('HD7', 'N10SP2');

-- --------------------------------------------------------

--
-- Table structure for table `chucnang`
--

CREATE TABLE `chucnang` (
  `MaChucNang` varchar(8) NOT NULL,
  `TenChucNang` varchar(300) NOT NULL,
  `hinhanh` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chucnang`
--

INSERT INTO `chucnang` (`MaChucNang`, `TenChucNang`, `hinhanh`) VALUES
('abc', 'chucnangabc', 'chucnangabc'),
('HD', 'Hóa đơn', 'hoadon.jfif'),
('KH', 'Khách hàng', 'khachhang.png'),
('KM', 'Khuyến mãi và lợi nhuận', 'khuyenmai.png'),
('NV', 'Nhân viên', 'nhanvien.png'),
('PBH', 'Phiếu bảo hành', 'baohanh.jfif'),
('PNH', 'Phiếu nhập hàng', 'phieunhap.png'),
('SP', 'Sản phẩm', 'sanpham.jfif'),
('TK', 'Tài khoản', 'taikhoan.png');

-- --------------------------------------------------------

--
-- Table structure for table `hang`
--

CREATE TABLE `hang` (
  `MaHang` varchar(8) NOT NULL,
  `TenHang` varchar(300) NOT NULL,
  `TinhTrang` tinyint(1) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hang`
--

INSERT INTO `hang` (`MaHang`, `TenHang`, `TinhTrang`) VALUES
('ACER', 'Acer', 0),
('ASUS', 'Asus', 0),
('DELL', 'Dell', 0),
('HP', 'HP', 0),
('LENOVO', 'Lenovo', 0),
('MAC', 'Mac1', 1),
('MSI', 'MSI', 0);

-- --------------------------------------------------------

--
-- Table structure for table `hoadon`
--

CREATE TABLE `hoadon` (
  `MaHD` varchar(8) NOT NULL,
  `MaKH` varchar(8) NOT NULL,
  `MaNV` varchar(8) NOT NULL,
  `NgayLapHD` date NOT NULL,
  `DiaChi` varchar(500) NOT NULL,
  `TinhTrang` tinyint(1) UNSIGNED NOT NULL,
  `TongTien` int(10) UNSIGNED NOT NULL,
  `TongTienKM` int(10) UNSIGNED NOT NULL,
  `TongTienPhaiTra` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hoadon`
--

INSERT INTO `hoadon` (`MaHD`, `MaKH`, `MaNV`, `NgayLapHD`, `DiaChi`, `TinhTrang`, `TongTien`, `TongTienKM`, `TongTienPhaiTra`) VALUES
('HD1', 'KH000003', 'no', '2021-05-17', 'abc', 2, 55000000, 0, 55000000),
('HD2', 'KH000003', 'no', '2021-05-17', 'abc', 2, 90200000, 0, 90200000),
('HD3', 'KH000003', 'S002', '2021-05-17', 'abc', 2, 90200000, 0, 90200000),
('HD4', 'KH000003', 'no', '2021-05-17', 'abc', 2, 90200000, 0, 90200000),
('HD5', 'KH000003', 'S002', '2021-05-17', 'abc', 2, 27500000, 0, 27500000),
('HD6', 'KH9', 'no', '2021-05-17', 'abc', 2, 252720000, 0, 252720000),
('HD7', 'KH9', 'S002', '2021-05-17', 'abc', 2, 27500000, 0, 27500000);

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE `khachhang` (
  `MaKH` varchar(8) NOT NULL,
  `MaTK` varchar(8) NOT NULL,
  `Ho` varchar(256) NOT NULL,
  `Ten` varchar(50) NOT NULL,
  `DiaChi` varchar(500) NOT NULL,
  `DienThoai` varchar(10) NOT NULL,
  `NgaySinh` date NOT NULL,
  `GioiTinh` tinyint(1) UNSIGNED NOT NULL,
  `TinhTrang` tinyint(1) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`MaKH`, `MaTK`, `Ho`, `Ten`, `DiaChi`, `DienThoai`, `NgaySinh`, `GioiTinh`, `TinhTrang`) VALUES
('KH000001', 'TK001', 'Nguyễn Văn Minh', 'Đức', '2/1A Liên Khu 2-10, P.Bình Hưng Hòa A, Q.Bình Tân', '0368708796', '2001-04-14', 0, 0),
('KH000002', 'TK002', 'Trần Thị', 'E', 'abcxyz', '0123456789', '2001-05-04', 1, 0),
('KH000003', 'KH000003', 'Nguyễn', 'B', 'abc', '0123456789', '2021-05-11', 0, 0),
('KH000004', 'KH000004', 'Nguyễn Thị', 'C', 'xyz', '0987654321', '2021-04-25', 1, 0),
('KH000005', 'KH000005', 'Trần Văn', 'An', 'tyu', '0839716253', '2021-03-03', 0, 0),
('KH000006', 'KH000006', 'Phan Thị', 'Dần', 'abc', '0781239564', '2001-04-03', 0, 0),
('KH000007', 'KH000007', 'Mai Thị', 'T', '123 abc', '0789654123', '2001-01-16', 1, 0),
('KH9', 'KH9', 'abc', 'abc', 'abc', '0123456789', '2021-01-11', 0, 0),
('khaKH', 'khaKH', 'Nguyễn Văn', 'A', 'abcxyz', '0123456789', '2021-05-11', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `khuyenmai`
--

CREATE TABLE `khuyenmai` (
  `MaKM` varchar(8) NOT NULL,
  `TenCTKM` varchar(300) NOT NULL,
  `NgayBatDau` date NOT NULL,
  `NgayKetThuc` date NOT NULL,
  `TinhTrang` tinyint(1) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `khuyenmai`
--

INSERT INTO `khuyenmai` (`MaKM`, `TenCTKM`, `NgayBatDau`, `NgayKetThuc`, `TinhTrang`) VALUES
('KM1', 'Khuyến mãi 30/4-1/5', '2021-04-29', '2021-05-03', 1),
('KM2', 'Lễ thiếu nhi 1/6', '2021-05-11', '2021-05-26', 0),
('KM3', 'Summer', '2021-05-04', '2021-05-07', 1),
('KM4', 'Mùa hè', '2021-05-24', '2021-05-31', 2),
('KM5', 'Khai giảng năm học mới', '2021-08-31', '2021-09-15', 2),
('KM6', 'Giáng sinh', '2021-12-20', '2021-12-30', 2),
('KM7', 'abc', '2021-05-16', '2021-05-25', 0);

-- --------------------------------------------------------

--
-- Table structure for table `loai`
--

CREATE TABLE `loai` (
  `MaLoai` varchar(8) NOT NULL,
  `TenLoai` varchar(256) NOT NULL,
  `TinhTrang` tinyint(1) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loai`
--

INSERT INTO `loai` (`MaLoai`, `TenLoai`, `TinhTrang`) VALUES
('G1', 'Laptop1', 1),
('GAMING', 'Laptop Gaming', 0),
('VANPHONG', 'Laptop văn phòng', 0);

-- --------------------------------------------------------

--
-- Table structure for table `loinhuan`
--

CREATE TABLE `loinhuan` (
  `MaLoiNhuan` varchar(8) NOT NULL,
  `MaNhomSP` varchar(8) NOT NULL,
  `PhanTramLoiNhuan` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loinhuan`
--

INSERT INTO `loinhuan` (`MaLoiNhuan`, `MaNhomSP`, `PhanTramLoiNhuan`) VALUES
('LN05', 'N5', 10),
('LN06', 'N6', 10),
('LN07', 'N7', 15),
('LN08', 'N8', 10),
('LN09', 'N9', 10),
('LN1', 'N1', 8),
('LN10', 'N10', 10),
('LN11', 'N11', 10),
('LN12', 'N12', 10),
('LN13', 'N13', 10),
('LN14', 'N14', 10),
('LN15', 'N15', 10),
('LN16', 'N16', 10),
('LN17', 'N17', 10),
('LN18', 'N18', 10),
('LN19', 'N19', 10),
('LN2', 'N2', 10),
('LN20', 'N20', 10),
('LN21', 'N21', 10),
('LN22', 'N22', 10),
('LN23', 'N23', 10),
('LN24', 'N24', 10),
('LN25', 'N25', 10),
('LN26', 'N26', 10),
('LN27', 'N27', 10),
('LN28', 'N28', 10),
('LN29', 'N29', 10),
('LN3', 'N3', 8),
('LN30', 'N30', 10),
('LN31', 'N31', 10),
('LN32', 'N32', 10),
('LN33', 'N33', 10),
('LN34', 'N34', 10),
('LN4', 'N4', 10);

-- --------------------------------------------------------

--
-- Table structure for table `nhacungcap`
--

CREATE TABLE `nhacungcap` (
  `MaNCC` varchar(8) NOT NULL,
  `TenNCC` varchar(300) NOT NULL,
  `TinhTrang` tinyint(1) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nhacungcap`
--

INSERT INTO `nhacungcap` (`MaNCC`, `TenNCC`, `TinhTrang`) VALUES
('NCC01', 'ACER', 0),
('NCC02', 'ASUS', 0),
('NCC03', 'DELL', 0),
('NCC04', 'HP', 0),
('NCC05', 'LENOVO', 0),
('NCC06', 'MACBOOK', 0);

-- --------------------------------------------------------

--
-- Table structure for table `nhanvien`
--

CREATE TABLE `nhanvien` (
  `MaNV` varchar(8) NOT NULL,
  `MaTK` varchar(8) NOT NULL,
  `Ho` varchar(256) NOT NULL,
  `Ten` varchar(50) NOT NULL,
  `DiaChi` varchar(500) NOT NULL,
  `DienThoai` varchar(10) NOT NULL,
  `NgaySinh` date NOT NULL,
  `GioiTinh` tinyint(1) UNSIGNED NOT NULL,
  `Email` varchar(256) NOT NULL,
  `TinhTrang` tinyint(1) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nhanvien`
--

INSERT INTO `nhanvien` (`MaNV`, `MaTK`, `Ho`, `Ten`, `DiaChi`, `DienThoai`, `NgaySinh`, `GioiTinh`, `Email`, `TinhTrang`) VALUES
('no', 'NV01', 'no', 'no', 'no', 'no', '2021-05-17', 0, 'no', 1),
('S001', 'TK001', 'Lê Thiên ', 'Vũ', 'Quận 8', '0123456789', '2000-07-27', 0, 'ltvu12@gmail.com', 0),
('S002', 'AD', 'Nguyễn Văn Minh', 'Đức', 'Quận 10', '0159632478', '2001-01-01', 0, 'nguyenvmduc@gmail.com', 0),
('S003', 'TK001', 'Tô Phương', 'Dũng', 'Quận 6', '0789123456', '2001-09-08', 0, 'tophuongdung2001@gmail.com', 0),
('S004', 'TK001', 'Nguyễn Đình Trung', 'Hiếu', 'Quận Tân Phú', '0147963258', '2001-06-09', 1, 'ndthieu2001@gmail.com', 0),
('S005', 'S005', 'Nguyễn Văn', 'F', 'abc', '0123456678', '2001-06-20', 0, 'abcd@gmail.com', 0),
('S006', 'S006', 'Nguyễn Văn', 'D', 'áccs', '0123456678', '2021-05-27', 0, 'abcd@gmail.com', 0),
('S007', 'S007', 'Trần Thị', 'C', 'xyz', '0129783469', '2001-06-13', 0, 'ab@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `phieubaohanh`
--

CREATE TABLE `phieubaohanh` (
  `MaBaoHanh` varchar(8) NOT NULL,
  `MaSanPham` varchar(8) NOT NULL,
  `TuNgay` date NOT NULL,
  `DenNgay` date NOT NULL,
  `TinhTrang` tinyint(1) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `phieubaohanh`
--

INSERT INTO `phieubaohanh` (`MaBaoHanh`, `MaSanPham`, `TuNgay`, `DenNgay`, `TinhTrang`) VALUES
('BH1', 'N10SP1', '2019-05-16', '2021-05-16', 0),
('BH2', 'N10SP2', '2021-05-17', '2023-05-16', 0),
('BH3', 'N10SP3', '2021-05-17', '2023-05-16', 0),
('BH4', 'N10SP4', '2021-05-16', '2023-05-16', 0),
('BH5', 'N10SP5', '2021-05-15', '2023-05-16', 0),
('BH6', 'N10SP6', '2021-05-16', '2023-05-16', 0),
('BH7', 'N10SP7', '2021-05-15', '2023-05-16', 0),
('BH8', 'N10SP1', '2021-05-17', '2023-05-17', 0),
('BH9', 'N10SP2', '2021-05-17', '2023-05-17', 0);

-- --------------------------------------------------------

--
-- Table structure for table `phieunhaphang`
--

CREATE TABLE `phieunhaphang` (
  `MaPN` varchar(8) NOT NULL,
  `MaNCC` varchar(8) NOT NULL,
  `MaNV` varchar(9) NOT NULL,
  `NgayNhap` date NOT NULL,
  `TongTien` bigint(11) UNSIGNED NOT NULL,
  `TinhTrang` tinyint(1) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `phieunhaphang`
--

INSERT INTO `phieunhaphang` (`MaPN`, `MaNCC`, `MaNV`, `NgayNhap`, `TongTien`, `TinhTrang`) VALUES
('PN01', 'NCC01', 'S001', '2019-12-12', 200000000, 0),
('PN02', 'NCC05', 'S002', '2020-02-01', 235000000, 0),
('PN03', 'NCC03', 'S003', '2020-03-12', 510000000, 0),
('PN04', 'NCC04', 'S004', '2020-04-12', 260000000, 0),
('PN05', 'NCC01', 'S002', '2021-05-14', 287000000, 0),
('PN06', 'NCC05', 'S002', '2021-05-14', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `quyentk`
--

CREATE TABLE `quyentk` (
  `MaQuyen` varchar(8) NOT NULL,
  `TenQuyen` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `quyentk`
--

INSERT INTO `quyentk` (`MaQuyen`, `TenQuyen`) VALUES
('abc', 'abc'),
('ADMIN', 'Quản lý tài khoản'),
('KH', 'Khách hàng'),
('NHANVIEN', 'Quyền nhân viên'),
('QUANLY', 'Toàn quyền hệ thống');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `MaNhomSP` varchar(8) NOT NULL,
  `MaLoai` varchar(8) NOT NULL,
  `MaHang` varchar(8) NOT NULL,
  `TenSP` varchar(300) NOT NULL,
  `TenHinh` varchar(100) NOT NULL,
  `MoTa` varchar(1000) NOT NULL,
  `SoLuong` tinyint(3) UNSIGNED NOT NULL,
  `GiaGoc` int(10) UNSIGNED NOT NULL,
  `TinhTrang` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`MaNhomSP`, `MaLoai`, `MaHang`, `TenSP`, `TenHinh`, `MoTa`, `SoLuong`, `GiaGoc`, `TinhTrang`) VALUES
('N1', 'GAMING', 'ACER', 'Laptop Acer Nitro AN515 55 72P6 i7 10750H/8GB/512GB/4GB GTX1650/144Hz/Win10', 'vi-vn-acer-nitro-an515-55-72p6-i7-nhqbnsv004-4.jpg', 'Acer Nitro AN515 55 72P6 i7 (NH.QBNSV.004) là chiếc laptop gaming được thiết kế theo phòng cách hiện đại, cá tính mà vẫn đảm bảo độ mỏng nhẹ để tiện lợi xê dịch. Cấu hình mạnh mẽ với chip Core i7 dòng H kết hợp cùng hiệu năng đồ họa khủng của GPU rời GeForce GTX 1650 4GB cho bạn trải nghiệm chiến game cực đỉnh.', 10, 26000000, 0),
('N10', 'GAMING', 'ASUS', 'Laptop Asus TUF Gaming FX506LI i7 10870H/8GB/512GB/144Hz/4GB GTX1650Ti/Win10 (HN096T) ', 'asus-tuf-gaming-fx506li-i7-hn096t-260121-0439291.jpg', 'Laptop Asus TUF Gaming FX506LI i7 (HN096T) sở hữu cấu hình mạnh mẽ cùng vẻ ngoài chuẩn gaming, đây sẽ là \"trợ thủ\" hoàn hảo dành cho game thủ và nhu cầu đa nhiệm tác vụ nặng. ', 9, 25000000, 0),
('N11', 'GAMING', 'ASUS', 'Laptop Asus TUF Gaming FX506LI i5 10300H/8GB/512GB/144Hz/4GB GTX1650Ti/Win10 (HN039T)', 'vi-vn-asus-tuf-gaming-fx506li-i5-hn039t--12.jpg', 'Asus TUF Gaming FX506LI i5 (HN039T) là mẫu laptop gaming tầm trung với thiết kế cá tính mạnh mẽ, hiệu năng cao, màn hình hiển thị đẹp. Đây chính là chiếc laptop lí tưởng cho cả học tập, làm việc, thiết kế đồ họa và đặc biệt là chiến game cực đã.', 0, 22000000, 0),
('N12', 'VANPHONG', 'ASUS', 'Laptop Asus VivoBook A415EA i5 1135G7/8GB/32GB+512GB//Win10 (AM889T) ', 'asus-vivobook-a415ea-i5-am889t-1-800x447.jpeg', 'Laptop Asus VivoBook A415EA i5 (AM889T) có cấu hình mạnh mẽ, ổn định với con chip Intel thế hệ 11 và một thiết kế cực kì thân thiện với học sinh sinh viên, mỏng nhẹ và thanh lịch. ', 0, 19000000, 0),
('N13', 'VANPHONG', 'ASUS', 'Laptop Asus VivoBook X515MA N5030/4GB/512GB/Win10 (EJ120T) ', 'asus-vivobook-x515ma-n5030-ej120t-221220-0744100.jpg', 'Laptop Asus VivoBook X515MA (EJ120T) có cấu hình ổn định, thực hiện tốt những nhu cầu lướt web, xem phim,... cơ bản hằng ngày thích hợp với những sinh viên hay dân văn phòng cần một chiếc máy có giá phải chăng để học online hay làm việc với Word, Excel.', 3, 41000000, 0),
('N14', 'VANPHONG', 'ASUS', 'Laptop Asus VivoBook X509JP i5 1035G1/8GB/512GB/2GB MX330/Win10 (EJ023T)\r\n\r\n', 'asus-vivobook-x509jp-i5-ej023t-115520-075501-011.jpg', 'Asus VivoBook X509JP i5 (EJ023T) là chiếc laptop học tập - văn phòng mỏng nhẹ, cấu hình mạnh và ổn định cho nhu cầu làm việc, giải trí hằng ngày. Ngoài ra, máy cũng có khả năng đồ họa khá nhờ có card đồ họa rời. ', 0, 15000000, 0),
('N15', 'VANPHONG', 'ASUS', 'Laptop Asus VivoBook X515MA N4020/4GB/256GB/Win10 (BR111T) ', 'Untitled-1-800x444.jpg', 'Laptop Asus VivoBook X515MA (BR111T) là một mẫu laptop học tập - văn phòng có thiết kế gọn nhẹ, hiệu năng ổn định phù hợp với các bạn thường xuyên sử dụng các ứng dụng văn phòng nhẹ nhàng.', 0, 8000000, 0),
('N16', 'GAMING', 'ASUS', 'Laptop Asus ZenBook UX325EA i5 1135G7/8GB/256GB/Túi/Win10 (EG079T) ', 'vi-vn-asus-zenbook-ux325ea-i5-eg079t-1.jpg', 'Laptop Asus ZenBook UX325EA i5 (EG079T) sở hữu hiệu năng mạnh mẽ từ vi xử lý Intel thế hệ 11 cùng với thiết kế kim loại siêu mỏng nhẹ mang tới vẻ đẳng cấp, sang trọng cho người dùng. ', 0, 22000000, 0),
('N17', 'VANPHONG', 'DELL', 'Laptop Dell XPS 13 9310 i7 1165G7/16GB/512GB/Touch/Pen/Win10 (JGNH61)', 'dell-xps-13-9310-i7-jgnh61-291220-013540-812.jpg', 'Dell XPS 13 9310 i7 (JGNH61) là một chiếc laptop 2 trong 1 mỏng nhẹ và sang trọng, phù hợp cho giới doanh nhân thành đạt. Với hiệu năng vô cùng mạnh mẽ đến từ con chip i7 gen 11, con laptop này sẽ khiến bạn không khỏi ngạc nhiên bởi khả năng vượt trội của nó.', 0, 65000000, 0),
('N18', 'GAMING', 'DELL', 'Laptop Dell G5 15 5500 i7 10750H/16GB/512GB/144Hz/6GB RTX2060/Win10 (70228123)', 'dell-g5-15-5500-i7-70228123-140121-0945259.jpg', 'Laptop Dell G5 15 5500 i7 (70228123) với cấu hình mạnh mẽ, thiết kế đẹp mắt, chiếc laptop Dell này sẽ đem lại trải nghiệm chơi game cực đã, làm việc mượt mà.', 0, 30000000, 0),
('N19', 'GAMING', 'DELL', 'Laptop Dell G5 15 5500 i7 10750H/8GB/512GB/120Hz/6GB GTX1660Ti/Win10 (70225485) ', 'dell-g5-15-5500-i7-70225485-120121-0957112.jpg', 'Laptop Dell G5 15 5500 i7 (70225485) là mẫu laptop gaming được thiết kế theo phong cách lịch lãm đầy mạnh mẽ. Cấu hình mạnh, hiệu suất đồ họa cao cùng màn hình lý tưởng cho việc chơi game là những ưu điểm khiến chiếc laptop này trở nên nổi bật trong phân khúc. ', 0, 32000000, 0),
('N2', 'VANPHONG', 'ACER', 'Laptop Acer Aspire 5 A514 54 33WY i3 1115G4/4GB/256GB/Win10 (NX.A23SV.00J) ', 'acer-aspire-5-a514-54-33wy-i3-nxa23sv00j-031220-1159230.jpg', 'Laptop Acer Aspire 5 A514 54 33WY i3 (NX.A23SV.00J) là chiếc laptop mỏng nhẹ đáp ứng hoàn hảo nhu cầu học tập và công việc văn phòng của bạn, sở hữu vi xử lí Intel thế hệ 11, ổ cứng SSD 256 GB cực nhanh và thiết kế sang trọng, di động tối ưu.', 0, 14000000, 0),
('N20', 'VANPHONG', 'DELL', 'Laptop Dell G3 15 3500 i5 10300H/8GB/256GB+1TB/120Hz/4GB GTX1650/Win10 (70223130) ', 'dell-g3-15-3500-i5-800x444.jpg', 'Laptop Dell G3 15 3500 i5 (70223130) là chiếc laptop gaming thuộc series G của nhà Dell với thiết kế cực ngầu và hiệu năng mạnh mẽ, hứa hẹn sẽ là người bạn đồng hành của các game thủ trong mọi cuộc chiến. ', 10, 26000000, 0),
('N21', 'VANPHONG', 'DELL', 'Laptop Dell Vostro 3500 i5 1135G7/8GB/256GB/2GB MX330/Win10 (P90F006V3500B)', 'dell-vostro-3500-i5-v3500b-010321-0923403.jpg', 'Với cấu hình kết hợp của Intel Core i5 thế hệ thứ 11 và card đồ họa rời NVIDIA GeForce MX330, Dell Vostro 3500 i5 (P90F006V3500B) sẽ mang đến cho bạn một sản phẩm chơi game mạnh mẽ trong thiết kế khá gọn nhẹ.', 0, 23000000, 0),
('N22', 'VANPHONG', 'DELL', 'Laptop Dell Inspiron 3501 i5 1135G7/4GB/512GB/Win10 (P90F005N3501B)', 'dell-inspiron-3501-i5-n3501b-040321-0843420.jpg', 'Được trang bị chip Intel Core i5 thế hệ 11 tiên tiến, Dell Inspiron 3501 i5 (P90F005N3501B) là mẫu laptop có cấu hình ổn định, mạnh mẽ cùng với thiết kế đặc trưng, đẹp mắt, hướng đến đối tượng là dân văn phòng, các bạn học sinh, sinh viên.', 0, 17000000, 0),
('N23', 'VANPHONG', 'DELL', 'Laptop Dell Vostro 3500 i5 1135G7/8GB/256GB/Win10 (7G3981) ', '235374-600x600.jpg', 'Dell Vostro 3500 i5 (7G3981) là một chiếc laptop khá gọn nhẹ dành cho các bạn học sinh, sinh viên cũng như dân văn phòng. Với bộ vi xử lý Intel thế hệ thứ 11 vô cùng mạnh mẽ, con laptop này sẽ giúp bạn hoàn thành công việc một cách nhanh chóng.', 0, 15000000, 0),
('N24', 'GAMING', 'HP', 'Laptop HP Omen 15 ek0078TX i7 10750H/16GB/1TB SSD/8GB RTX2070 Max-Q/300Hz/Office H&S2019/Win10 (26Y68PA) ', 'Tong-quan-800x444.jpg', 'HP Omen 15 ek0078TX i7 (26Y68PA) là chiếc laptop gaming mang trong mình sức mạnh siêu phàm nhờ sở hữu cấu hình gồm con chip Intel Core i7 mạnh mẽ và vi xử lý đồ họa cực mượt mà nhưng vẫn giữ ngoại hình tương đối mỏng nhẹ, đây chính là công cụ đắc lực, đồng hành cùng bạn trong mọi cuộc chiến.', 0, 60000000, 0),
('N25', 'GAMING', 'HP', 'Laptop HP Envy 15 ep0145TX i7 10750H/16GB/1TB SSD/6GB GTX 1660Ti Max-Q/Office H&S2019/Touch/Win10 (231V7PA)', 'hp-envy-15-ep1045tx-i7-231v7pa-061120-0948340.jpg', 'HP Envy 15 ep1045TX i7 (231V7PA) thể hiện sự đẳng cấp của mình với thiết kế kim loại nguyên khối sang trọng, hiệu năng đỉnh nhờ trang bị chip Intel dòng H thế hệ 10 cùng độ bảo mật tối ưu. HP Envy là chiếc laptop lý tưởng dành cho doanh nhân, người làm đồ họa kỹ thuật.', 0, 55000000, 0),
('N26', 'GAMING', 'HP', 'Laptop HP EliteBook X360 1040 G7 i7 10710U/16GB/512GB+32GB/Pen/Touch/Win10 Pro (230P8PA) ', 'hp-elitebook-x360-1040-g7-i7-230p8pa-311220-0239481.jpg', 'Laptop HP EliteBook X360 1040 (230P8PA) là một phiên bản laptop với thiết kế mỏng nhẹ cùng với chip Core i7 hiệu năng mạnh mẽ. Đây thực sự là con laptop đáng mong đợi dành cho doanh nhân hay các bạn có nhu cầu di chuyển cao.', 0, 50000000, 0),
('N27', 'VANPHONG', 'HP', 'Laptop HP 348 G7 i5 10210U/8GB/512GB/Win10 (9PH06PA) ', 'hp-348-g7-i5-9ph06pa-135120-105119.jpg', 'Laptop HP 348 G7 i5 (9PH06PA) là mẫu laptop giá mềm, thiết kế đẹp của HP, tập trung vào cấu hình và các tiện ích sử dụng. Máy phù hợp cho các bạn sinh viên hay nhân viên văn phòng dùng để xử lý công việc, học tập và giải trí hàng ngày.', 0, 18000000, 0),
('N28', 'VANPHONG', 'HP', 'Laptop HP Pavilion 15 eg0005TX i5 1135G7/8GB/512GB/2GB MX450/Office H&S2019/Win10 (2D9C6PA) ', 'vi-vn-hp-pavilion-15-eg0005tx-i5-2d9c6pa-1.jpg', 'Laptop HP Pavilion 15 eg0005TX i5 (2D9C6PA) được thiết kế theo xu hướng hiện đại với ngoại hình sang trọng, mỏng nhẹ và màn hình viền cực mỏng, bên trong là bộ vi xử lí Intel gen 11 mạnh mẽ, thích hợp với công việc văn phòng, thiết kế đồ họa. ', 0, 20000000, 0),
('N29', 'VANPHONG', 'HP', 'Laptop HP Pavilion x360 dw1019TU i7 1165G7/8GB/512GB/Touch/Pen/Office H&S2019/Win10 (2H3N7PA)', 'vi-vn-hp-pavilion-x360-dw1019tu-i7-2h3n7pa-1.jpg', 'HP Pavilion x360 dw1019TU i7 (2H3N7PA) là một chiếc laptop cực kỳ lý tưởng cùng với bộ vi xử lý Intel Core i7 thế hệ thứ 11 mạnh mẽ, mang đến cho bạn một trải nghiệm trọn vẹn với thiết kế đầy di động và sang trọng.', 0, 22000000, 0),
('N3', 'GAMING', 'ACER', 'Laptop Acer Nitro 5 A515 55 72R2 i7 10870H/8GB/512GB/144Hz/4GB GTX1650Ti/Win10 (NH.Q7NSV.005) ', 'acer-nitro-5-a515-55-72r2-i7-nhq7nsv005-091220-0301580.jpg', 'Acer Nitro 5 A515 55 72R2 i7 (NH.Q7NSV.005) là chiếc máy tính xách tay gaming đa năng vừa phù hợp với nhu cầu chơi game, vừa hỗ trợ công việc đồ họa chuyên nghiệp. Với thiết kế đầy cá tính kết hợp với một cấu hình đáng gờm, Acer Nitro đem đến những giây phút chiến game hoàn hảo.', 0, 28000000, 0),
('N30', 'GAMING', 'HP', 'Laptop HP Envy 13 ba1030TU i7 1165G7/8GB/512GB/Office H&S2019/Win10 (2K0B6PA) ', 'hp-envy-13-ba1030tu-i7-2k0b6pa-171120-1009350.jpg', 'Laptop HP Envy 13 ba1030TU i7 (2K0B6PA) sở hữu thiết kế mỏng nhẹ cùng cấu hình cực mạnh mẽ đáp ứng đa dạng nhu cầu làm việc, giúp bạn đạt được hiệu suất làm việc tốt nhất.', 0, 27000000, 0),
('N31', 'GAMING', 'HP', 'Laptop HP Pavilion Gaming 15 dk1159TX i7 10750H/8GB/32GB+512GB/4GB GTX1650Ti/Win10 (31J36PA) ', 'vi-vn-hp-pavilion-gaming-15-dk1159tx-i7-31j36pa-1.jpg', 'HP Pavilion Gaming 15 dk1159TX i7 (31J36PA) có hiệu năng đa nhiệm mạnh mẽ với chip Intel Core i7 Gen 10 và card GTX 1650Ti 4GB mang đến trải nghiệm chơi game giải trí, làm việc hoàn hảo.', 0, 30000000, 0),
('N32', 'VANPHONG', 'LENOVO', 'Laptop Lenovo IdeaPad S145 15IIL i3 1005G1/4GB/256GB/Win10 (81W8001XVN)', 'lenovo-ideapad-s145-81w8001xvn-113720-023732.jpg', 'Laptop Lenovo IdeaPad S145 15IIL i3 (81W8001XVN) thuộc phân khúc laptop học tập văn phòng cơ bản với mức giá tốt. Máy có cấu hình ổn, đủ chạy các ứng dụng văn phòng phổ biến, điểm nổi bật của Lenovo IdeaPad S145 là ổ cứng SSD siêu nhanh, thiết kế mỏng gọn, tinh tế.', 0, 12000000, 0),
('N33', 'VANPHONG', 'LENOVO', 'Laptop Lenovo IdeaPad Slim 3 15IIL05 i3 1005G1/4GB/512GB/Win10 (81WE003RVN)', 'lenovo-ideapad-3-15iil05-i3-81we003rvn-080720-0426490.jpg', 'Laptop Lenovo IdeaPad 3 15IIL05 là sản phẩm hướng đến người dùng văn phòng, học sinh sinh viên, xử lý ổn định các tác vụ cơ bản hằng ngày.', 0, 13000000, 0),
('N34', 'GAMING', 'LENOVO', 'Laptop Lenovo YOGA Slim 7 Carbon 13ITL5 i7 1165G7/16GB/1TB SSD/Win10 (82EV0017VN)', 'lenovo-yoga-slim-7-carbon-13itl5-i7-82ev0017vn-250321-0139501.jpg', 'Siêu phẩm laptop Lenovo YOGA Slim 7 Carbon 13ITL5 i7 (82EV0017VN) cực mỏng nhẹ và bền bỉ với trọng lượng chưa đến 1 kg. Hiệu năng mạnh mẽ cùng màn hình QHD siêu nét và hệ thống bảo mật tân tiến là những ưu điểm khiến chiếc laptop này trở nên thu hút không thể bỏ qua.', 0, 32000000, 0),
('N4', 'VANPHONG', 'ACER', 'Laptop Acer Swift 5 SF514 53T 740R i7 8565U/8GB/256GB/Touch/Win10 (NX.H7KSV.002) ', 'vi-vn-acer-swit-5-sf514-53t-740r-i7-8565u-8gb-256gb-14f-cau-hinh-manh.jpg', 'Laptop Acer Swift 5 SF514 53T 740R là dòng sản phẩm Ultrabook của Acer hướng đến đối tượng là doanh nhân khi mang trong mình trọng lượng chỉ 0.94 kg, dày 14.9 mm - một trong những chiếc laptop mỏng nhẹ nhất ở thời điểm hiện tại. ', 0, 29000000, 0),
('N5', 'GAMING', 'ACER', 'Laptop Acer Nitro 5 AN515 55 5206 i5/10300H/8GB/512GB/144Hz/4GB GTX1650Ti/Win10 (NH.Q7NSV.007)', 'acer-nitro-5-an515-55-5206-i5-nhq7nsv007-101220-095647-201.jpg', 'Acer Nitro 5 AN515 55 5206 (NH.Q7NSV.007) là chiếc laptop đến từ thương hiệu Acer sẽ mang đến một cách nhìn hoàn toàn mới về các nhu cầu sử dụng trên dòng laptop gaming có thể mang lại cho người dùng bởi hiệu năng cực kỳ mạnh mẽ của nó.', 0, 24000000, 0),
('N6', 'VANPHONG', 'ACER', 'Laptop Acer Swift 3 SF315 52G 87N4 i7 8550U/8GB/128GB/2GB MX150/Win10 (NX.GZCSV.005)\r\n\r\n', 'vi-vn-sf315-i7.jpg', 'Laptop Acer Swift 3 SF315 là mẫu laptop mỏng nhẹ cấu hình mạnh vừa ra mắt gây ấn tượng bởi vẻ ngoài sang trọng kết hợp cùng cấu hình khủng. ', 0, 24000000, 0),
('N7', 'GAMING', 'ACER', 'Laptop Acer Nitro 5 AN515 45 R3SM R5 5600H/8GB/512GB/4GB GTX1650/144Hz/Balo/Win10 (NH.QBMSV.005) ', 'vi-vn-acer-nitro-5-an515-45-r3sm-r5-nhqbmsv005-1.jpg', 'Laptop Acer Nitro 5 AN515 45 R3SM R5 (NH.QBMSV.005) có vẻ ngoài hình hầm hố đặc trưng của dòng laptop gaming, cấu hình mạnh mẽ chạy mượt các tựa game được các game thủ ưa thích với con chip AMD Ryzen 5 và card đồ họa NVIDIA GeForce GTX 1650 4GB.', 0, 24000000, 0),
('N8', 'GAMING', 'ACER', 'Laptop Acer Nitro AN515 44 R9JM R5 4600H/8GB/512GB/4GB GTX1650/144Hz/Win10 (NH.Q9MSV.003) ', 'acer-nitro-an515-44-r9jm-r5-nhq9msv003-fix-800x444.jpg', 'Với card đồ họa rời GTX 1650, Acer Nitro AN515 44 R9JM R5 (NH.Q9MSV.003) trở thành một con laptop đáng gờm bởi hiệu năng vô cùng mạnh mẽ. Đây sẽ là laptop được săn đón trong năm 2021 cũng bởi thiết kế hầm hố đậm chất game thủ của mình.', 0, 23000000, 0),
('N9', 'GAMING', 'ASUS', 'Laptop Asus TUF Gaming FX516PM i7 11370H/16GB/512GB/6GB RTX3060/144Hz/Win10 (HN023T) ', 'vi-vn-asus-tuf-gaming-fx516pm-i7-hn023t-1.jpg', 'Laptop Asus TUF Gaming FX516PM i7 (HN023T) sở hữu dòng chip CPU Intel Core i7 thế hệ 11 mạnh mẽ mang đến hiệu năng ấn tượng cho nhu cầu thiết kế đồ họa, làm việc văn phòng và cả chiến game cực chất.', 0, 33000000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `MaTK` varchar(8) NOT NULL,
  `MaQuyen` varchar(8) NOT NULL,
  `Username` varchar(32) NOT NULL,
  `Password` varchar(32) NOT NULL,
  `TinhTrang` tinyint(1) UNSIGNED NOT NULL,
  `NgayTaoTK` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`MaTK`, `MaQuyen`, `Username`, `Password`, `TinhTrang`, `NgayTaoTK`) VALUES
('AD', 'QUANLY', 'admin', 'admin', 1, '2021-05-13'),
('AD1', 'abc', 'admin123', 'admin123', 1, '2021-05-15'),
('KH000003', 'KH', 'KH000003', '12345', 1, '2021-05-11'),
('KH000004', 'KH', 'KH000004', '123', 0, '2021-05-11'),
('KH000005', 'KH', 'KH000005', '123', 0, '2021-05-11'),
('KH000006', 'KH', 'KH000006', '123', 0, '2021-05-11'),
('KH000007', 'KH', 'KH000007', '123', 1, '2021-05-12'),
('KH9', 'KH', 'abcdef', '12345678', 1, '2021-05-17'),
('khaKH', 'KH', 'khachhang123', '123456789', 1, '2021-05-17'),
('NV01', 'NHANVIEN', 'nhanvien', '123456', 1, '2021-05-15'),
('S005', 'NHANVIEN', 'S005', '123456', 0, '2021-05-12'),
('S006', 'NHANVIEN', 'S006', '123890', 1, '2021-05-12'),
('S007', 'NHANVIEN', 'S007', '123456', 0, '2021-05-12'),
('TK001', 'KH', 'khachhang', '123', 1, '2021-05-10'),
('TK002', 'KH', 'khachhang1', '456', 1, '2021-05-10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chitiethoadon`
--
ALTER TABLE `chitiethoadon`
  ADD KEY `mahd` (`MaHD`),
  ADD KEY `manhomsp4` (`MaNhomSP`);

--
-- Indexes for table `chitietkhuyenmai`
--
ALTER TABLE `chitietkhuyenmai`
  ADD KEY `makm` (`MaKM`),
  ADD KEY `manhomsp3` (`MaNhomSP`);

--
-- Indexes for table `chitietphieunhaphang`
--
ALTER TABLE `chitietphieunhaphang`
  ADD KEY `manhomsp1` (`MaNhomSP`),
  ADD KEY `mapn` (`MaPN`);

--
-- Indexes for table `chitietquyen`
--
ALTER TABLE `chitietquyen`
  ADD KEY `maquyen2` (`MaQuyen`),
  ADD KEY `machucnang3` (`MaChucNang`);

--
-- Indexes for table `chitietsanpham`
--
ALTER TABLE `chitietsanpham`
  ADD PRIMARY KEY (`MaSanPham`),
  ADD KEY `manhomsp` (`MaNhomSP`);

--
-- Indexes for table `chitietsanphamhoadon`
--
ALTER TABLE `chitietsanphamhoadon`
  ADD KEY `MaHD` (`MaHD`),
  ADD KEY `MaSanPham` (`MaSanPham`);

--
-- Indexes for table `chucnang`
--
ALTER TABLE `chucnang`
  ADD PRIMARY KEY (`MaChucNang`);

--
-- Indexes for table `hang`
--
ALTER TABLE `hang`
  ADD PRIMARY KEY (`MaHang`);

--
-- Indexes for table `hoadon`
--
ALTER TABLE `hoadon`
  ADD PRIMARY KEY (`MaHD`),
  ADD KEY `makh1` (`MaKH`),
  ADD KEY `manv` (`MaNV`);

--
-- Indexes for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD PRIMARY KEY (`MaKH`),
  ADD KEY `matk1` (`MaTK`);

--
-- Indexes for table `khuyenmai`
--
ALTER TABLE `khuyenmai`
  ADD PRIMARY KEY (`MaKM`);

--
-- Indexes for table `loai`
--
ALTER TABLE `loai`
  ADD PRIMARY KEY (`MaLoai`);

--
-- Indexes for table `loinhuan`
--
ALTER TABLE `loinhuan`
  ADD PRIMARY KEY (`MaLoiNhuan`),
  ADD KEY `manhomsp2` (`MaNhomSP`);

--
-- Indexes for table `nhacungcap`
--
ALTER TABLE `nhacungcap`
  ADD PRIMARY KEY (`MaNCC`);

--
-- Indexes for table `nhanvien`
--
ALTER TABLE `nhanvien`
  ADD PRIMARY KEY (`MaNV`),
  ADD KEY `matk` (`MaTK`);

--
-- Indexes for table `phieubaohanh`
--
ALTER TABLE `phieubaohanh`
  ADD PRIMARY KEY (`MaBaoHanh`),
  ADD KEY `mactsp` (`MaSanPham`);

--
-- Indexes for table `phieunhaphang`
--
ALTER TABLE `phieunhaphang`
  ADD PRIMARY KEY (`MaPN`),
  ADD KEY `manhacungcap` (`MaNCC`);

--
-- Indexes for table `quyentk`
--
ALTER TABLE `quyentk`
  ADD PRIMARY KEY (`MaQuyen`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`MaNhomSP`),
  ADD KEY `maloai` (`MaLoai`),
  ADD KEY `mahang` (`MaHang`);

--
-- Indexes for table `taikhoan`
--
ALTER TABLE `taikhoan`
  ADD PRIMARY KEY (`MaTK`),
  ADD KEY `maquyen1` (`MaQuyen`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chitiethoadon`
--
ALTER TABLE `chitiethoadon`
  ADD CONSTRAINT `mahd` FOREIGN KEY (`MaHD`) REFERENCES `hoadon` (`MaHD`),
  ADD CONSTRAINT `manhomsp4` FOREIGN KEY (`MaNhomSP`) REFERENCES `sanpham` (`MaNhomSP`);

--
-- Constraints for table `chitietkhuyenmai`
--
ALTER TABLE `chitietkhuyenmai`
  ADD CONSTRAINT `makm` FOREIGN KEY (`MaKM`) REFERENCES `khuyenmai` (`MaKM`),
  ADD CONSTRAINT `manhomsp3` FOREIGN KEY (`MaNhomSP`) REFERENCES `sanpham` (`MaNhomSP`);

--
-- Constraints for table `chitietphieunhaphang`
--
ALTER TABLE `chitietphieunhaphang`
  ADD CONSTRAINT `manhomsp1` FOREIGN KEY (`MaNhomSP`) REFERENCES `sanpham` (`MaNhomSP`),
  ADD CONSTRAINT `mapn` FOREIGN KEY (`MaPN`) REFERENCES `phieunhaphang` (`MaPN`);

--
-- Constraints for table `chitietquyen`
--
ALTER TABLE `chitietquyen`
  ADD CONSTRAINT `machucnang3` FOREIGN KEY (`MaChucNang`) REFERENCES `chucnang` (`MaChucNang`),
  ADD CONSTRAINT `maquyen2` FOREIGN KEY (`MaQuyen`) REFERENCES `quyentk` (`MaQuyen`);

--
-- Constraints for table `chitietsanpham`
--
ALTER TABLE `chitietsanpham`
  ADD CONSTRAINT `manhomsp` FOREIGN KEY (`MaNhomSP`) REFERENCES `sanpham` (`MaNhomSP`);

--
-- Constraints for table `chitietsanphamhoadon`
--
ALTER TABLE `chitietsanphamhoadon`
  ADD CONSTRAINT `chitietsanphamhoadon_ibfk_1` FOREIGN KEY (`MaHD`) REFERENCES `hoadon` (`MaHD`),
  ADD CONSTRAINT `chitietsanphamhoadon_ibfk_2` FOREIGN KEY (`MaSanPham`) REFERENCES `chitietsanpham` (`MaSanPham`);

--
-- Constraints for table `hoadon`
--
ALTER TABLE `hoadon`
  ADD CONSTRAINT `makh1` FOREIGN KEY (`MaKH`) REFERENCES `khachhang` (`MaKH`),
  ADD CONSTRAINT `manv` FOREIGN KEY (`MaNV`) REFERENCES `nhanvien` (`MaNV`);

--
-- Constraints for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD CONSTRAINT `matk1` FOREIGN KEY (`MaTK`) REFERENCES `taikhoan` (`MaTK`);

--
-- Constraints for table `loinhuan`
--
ALTER TABLE `loinhuan`
  ADD CONSTRAINT `manhomsp2` FOREIGN KEY (`MaNhomSP`) REFERENCES `sanpham` (`MaNhomSP`);

--
-- Constraints for table `nhanvien`
--
ALTER TABLE `nhanvien`
  ADD CONSTRAINT `matk` FOREIGN KEY (`MaTK`) REFERENCES `taikhoan` (`MaTK`);

--
-- Constraints for table `phieubaohanh`
--
ALTER TABLE `phieubaohanh`
  ADD CONSTRAINT `mactsp` FOREIGN KEY (`MaSanPham`) REFERENCES `chitietsanpham` (`MaSanPham`);

--
-- Constraints for table `phieunhaphang`
--
ALTER TABLE `phieunhaphang`
  ADD CONSTRAINT `manhacungcap` FOREIGN KEY (`MaNCC`) REFERENCES `nhacungcap` (`MaNCC`);

--
-- Constraints for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `mahang` FOREIGN KEY (`MaHang`) REFERENCES `hang` (`MaHang`),
  ADD CONSTRAINT `maloai` FOREIGN KEY (`MaLoai`) REFERENCES `loai` (`MaLoai`);

--
-- Constraints for table `taikhoan`
--
ALTER TABLE `taikhoan`
  ADD CONSTRAINT `maquyen1` FOREIGN KEY (`MaQuyen`) REFERENCES `quyentk` (`MaQuyen`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
